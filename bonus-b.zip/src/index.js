import React from "react";
import ReactDOM from "react-dom";

import "@reach/dialog/styles.css";
import "./main-styles.scss";

import { setDefaultClient, Client } from "micro-graphql-react";

import App from "./App";

const client = new Client({
  endpoint: "https://mylibrary.io/graphql-public",
  fetchOptions: { mode: "cors" }
});

setDefaultClient(client);

const rootElement = document.getElementById("root");
ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  rootElement
);
